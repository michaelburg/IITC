# LibraryApp

## Data

### db.json
{
  "books": [
    {
      "id": 1,
      "bookName": "",
      "authorsName": [],
      "numPages": 1,
      "shortDescription": "",
      "image": "",
      "numCopies": 1,
      "categories": [],
      "ISBN": ""
    }
  ],
  "history": [
    {
        "id":"",
        "operation":"",
        "time":1235464325,
        "bookName":""
    }
  ]
}

## CSS

### variables.css

### styles.css


## JS

### localAPI.js
url:String http://localhost:8001

### googleAPI.js

### main.js



## HTML

      | Book Name
image | Authors 
      | Num Pages ISBN
      | Categories
      | short desctiption
      | - Num Copies +


### index.html

### newbook.html

